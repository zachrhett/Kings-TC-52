F.R.I.E.N.D. TC-52 Final Functional Demo

Open preview.html first for the interactive preview.
Open index.html for the clean app version.

Key updates:
- Home screen matches the approved TC-52 concept.
- Dynamic priority circle opens the guided temperature mission.
- Temperature workflow matches the PowerPoint: target 165°F or above, actual 171°F.
- Preserves original F.R.I.E.N.D. code, screens, navigation, and aesthetic.
- Includes Associate, Department Leader, Store Leader, Training, Alerts, Metrics, and guided mission screens.
